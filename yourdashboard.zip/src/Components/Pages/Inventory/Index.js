import React from 'react';
import {Typography} from "antd";

export default function Inventory() {
  return (
    <div>
      <Typography.Title level={4}>Inventory</Typography.Title>
    </div>
  )
}