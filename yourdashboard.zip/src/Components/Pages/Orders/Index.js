import React from 'react'
import {Typography} from "antd";

export default function Orders() {
  return (
    <div>
      <Typography.Title level={4}>Orders</Typography.Title>
    </div>
  )
}