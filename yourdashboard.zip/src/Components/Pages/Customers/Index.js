import React from 'react'
import {Typography} from "antd";
export default function Customers() {
  return (
    <div>
      <Typography.Title level={4}>Customers</Typography.Title>
    </div>
  )
}
