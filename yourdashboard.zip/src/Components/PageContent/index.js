import React from 'react'
import AppRoutes from "../AppRoutes";
export default function PageContent() {
  return (
    <div className="PageContent">
     <AppRoutes/>
    </div>
  )
}
